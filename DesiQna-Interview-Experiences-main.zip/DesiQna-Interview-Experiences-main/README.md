# DesiQna-Interview-Experiences
DesiQna Interview Experiences Page
This is the Frontend Web page. Its purpose is to make user experience better and have all the Interview Experiences of different companies in a proper manner.

Tech Stack:

HTML

CSS

BOOTSTRAP

JAVASCRIPT
